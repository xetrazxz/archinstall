#!/bin/bash
set -e

arch-chroot /mnt /bin/bash <<EOF

grub-install --target=x86_64-efi --efi-directory=/efi --bootloader-id=Grub
grub-mkconfig -o /boot/grub/grub.cfg

EOF

echo "Bootloader installed."
