#!/bin/bash
set -e

arch-chroot /mnt /bin/bash <<EOF

useradd -m -G wheel xetra
echo xetra:dark | chpasswd

echo "%wheel ALL=(ALL:ALL) ALL" >> /etc/sudoers

pacman -Sy --noconfirm dhcpcd iwd

systemctl enable dhcpcd
systemctl enable iwd

EOF

echo "User and network configured."

