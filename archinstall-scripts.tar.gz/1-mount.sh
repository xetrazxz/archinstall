#!/bin/bash
set -e

# Format EFI
mkfs.fat -F32 /dev/sda1

# Format root partition as Btrfs
mkfs.btrfs -f /dev/sda2

# Mount and create subvolumes
mount /dev/sda2 /mnt

btrfs subvolume create /mnt/@
btrfs subvolume create /mnt/@home
btrfs subvolume create /mnt/@root
btrfs subvolume create /mnt/@snapshots
btrfs subvolume create /mnt/@var-cache
btrfs subvolume create /mnt/@var-log

umount /mnt

# Mount subvolumes with LZO compression and noatime
mount -o noatime,compress=lzo,subvol=@ /dev/sda2 /mnt
mkdir -p /mnt/{home,root,.snapshots,var/cache,var/log,efi}

mount -o noatime,compress=lzo,subvol=@home /dev/sda2 /mnt/home
mount -o noatime,compress=lzo,subvol=@root /dev/sda2 /mnt/root
mount -o noatime,compress=lzo,subvol=@snapshots /dev/sda2 /mnt/.snapshots
mount -o noatime,compress=lzo,subvol=@var-cache /dev/sda2 /mnt/var/cache
mount -o noatime,compress=lzo,subvol=@var-log /dev/sda2 /mnt/var/log

# Mount EFI partition
mount /dev/sda1 /mnt/efi

echo "Btrfs subvolumes and EFI mounted successfully."

