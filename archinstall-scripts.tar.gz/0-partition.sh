#!/bin/bash
set -e

DISK="/dev/sda"

# Wipe existing partition table
sgdisk --zap-all "$DISK"

# Create partitions
sgdisk -n1:0:+1G   -t1:ef00 "$DISK"   # EFI System
sgdisk -n2:0:+128G -t2:8300 "$DISK"   # Arch root
sgdisk -n3:0:+64G  -t3:8300 "$DISK"   # Test OS
sgdisk -n4:0:0     -t4:8300 "$DISK"   # Data/Games

echo "Partitioning complete on $DISK:"
lsblk "$DISK"

