#!/bin/bash
set -e

pacstrap /mnt base linux-zen linux-zen-headers linux-firmware btrfs-progs grub efibootmgr amd-ucode nano

genfstab -U /mnt >> /mnt/etc/fstab

echo "Base system installed."

